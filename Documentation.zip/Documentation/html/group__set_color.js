var group__set_color =
[
    [ "setColor", "group__set_color.html#gacd86a2fe450c8c6dcce8c993789135c2", null ],
    [ "setColor", "group__set_color.html#ga5db05ed6677dec2eb19e731dc79463b0", null ]
];
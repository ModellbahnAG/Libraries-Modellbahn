var struct_button_list_item =
[
    [ "button", "struct_button_list_item.html#acfa1827894392492d1c2d81c4014e5fe", null ],
    [ "next", "struct_button_list_item.html#a461f13caa177b0d951b0e4f20377cdd8", null ]
];
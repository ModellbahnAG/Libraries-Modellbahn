var struct_invocative =
[
    [ "Interfacial", "struct_invocative.html#ae98187fec55fee9073d01b1f4989edda", null ],
    [ "operator()", "struct_invocative.html#a98f28cac539f51cec3ded74b82fde0af", null ],
    [ "interface", "struct_invocative.html#aaba83f42f03d1694dd25fe17bf776898", null ],
    [ "locality", "struct_invocative.html#a98b9fb95b0c439d39090357c7dcaca95", null ]
];
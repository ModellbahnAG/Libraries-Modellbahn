var modules =
[
    [ "()", "group__set_color.html", "group__set_color" ]
];
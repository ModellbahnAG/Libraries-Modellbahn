var searchData=
[
  ['torch_48',['torch',['../class_light_effects.html#add1b8dbda9e3801f004a53c5dd85befd',1,'LightEffects']]]
];

var indexSectionsWithContent =
{
  0: "abcfghlmnost",
  1: "bcln",
  2: "blmn",
  3: "abfghnost",
  4: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Alle",
  1: "Klassen",
  2: "Dateien",
  3: "Funktionen",
  4: "Seiten"
};


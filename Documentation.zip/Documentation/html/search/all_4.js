var searchData=
[
  ['getnumberofpixels_11',['getNumberOfPixels',['../class_neo_pixel.html#a2baec551d5892662019a04f5943c8995',1,'NeoPixel']]]
];

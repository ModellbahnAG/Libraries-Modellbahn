var searchData=
[
  ['setbrightness_20',['setBrightness',['../class_neo_pixel.html#ae088cc6a5f22401a4f56696d13a8cc69',1,'NeoPixel']]],
  ['setcallback_21',['setCallback',['../class_button.html#a54a2b43509e6c28ba8b0a4c003ded6ba',1,'Button']]],
  ['setcolor_22',['setColor',['../class_neo_pixel.html#acd86a2fe450c8c6dcce8c993789135c2',1,'NeoPixel::setColor(CRGB color, int pixel)'],['../class_neo_pixel.html#a5db05ed6677dec2eb19e731dc79463b0',1,'NeoPixel::setColor(int r, int g, int b, int pixel)']]]
];

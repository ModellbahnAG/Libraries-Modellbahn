var searchData=
[
  ['fill_37',['fill',['../class_neo_pixel.html#a67e07318dc4aa8becf3edd3f75366413',1,'NeoPixel::fill(CRGB color, int start=0, int end=-1)'],['../class_neo_pixel.html#a0a3f77bcb43b73e4b88b13446291317b',1,'NeoPixel::fill(int r, int g, int b, int start=0, int end=-1)']]],
  ['fire_38',['fire',['../class_light_effects.html#ab0fbdb8ecb7807792f78f5bea47ca5c9',1,'LightEffects']]],
  ['flash_39',['flash',['../class_light_effects.html#a188308f811e28dbf52ec0d1b1fbd982b',1,'LightEffects']]]
];

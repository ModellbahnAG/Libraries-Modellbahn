var searchData=
[
  ['off_44',['off',['../class_neo_pixel.html#ae1b399d75b88295065e6846d3e0459c9',1,'NeoPixel']]]
];

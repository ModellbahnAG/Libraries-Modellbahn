var searchData=
[
  ['addbutton_0',['addButton',['../class_button_manager.html#abac14494a447472d4611f12f913d5260',1,'ButtonManager']]],
  ['ausstehende_20aufgaben_1',['Ausstehende Aufgaben',['../todo.html',1,'']]]
];
